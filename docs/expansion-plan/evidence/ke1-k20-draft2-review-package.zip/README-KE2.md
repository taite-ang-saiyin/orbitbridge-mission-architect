# KE1 to KE2: K20 draft 2 review package

Review target: shared main dce75db845f6c494b8c25c9028dd9c0648aabd91.
Contract: expansion-goals-v2-draft-2. Registry: five-presets-candidate-2.
Communication preset revision: 2, basic instrument + fast radio, 1120 g / 89 credits.

HPC and SE confirmations are PENDING. This package records KE2's relayed support
for the listed choices; it does not claim receipt or full team/integration approval.

Start with [the package guide](docs/ke1-expansion/ke2-review-package.md), then
[the revised K20 draft](docs/ke1-expansion/k20-interface-review.md).

Extract separately and inspect before copying individual files into matching paths
in the base project. This is a review overlay, not a standalone Godot project.
Preserve local edits. The guide lists required baseline modules and repeat commands.

Included: five-preset candidate registry, catalog API, tests and UID sidecars,
candidate-derived native-engine diagnostic, measured evidence and final test logs.
Excluded: personal AGENTS.md/GEMINI.md/tasks.md, editor caches, builds, exports,
downloaded PDFs and signed shared agreements.

Executed checks: 70 catalog + 265 starter + 294 existing validator = 629 passed,
zero failed. New objectives remain disabled. Current production validation still
rejects config v2; the diagnostic uses a test-only v1 Imaging physical surrogate.

The two-capture fast-radio trial returns 24 MB at steps 7/10. Its one-capture
control returns 12 MB at step 7 only, isolating the contact-count shortfall.

review-manifest.json lists every supplied file and its SHA256. No commit, push,
deployment or teammate message has been performed. Please review and reply using
the exact revisions above; production integration follows owner agreement.
