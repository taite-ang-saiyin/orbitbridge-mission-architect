# KE2 evidence for SE review

Prepared 15 November 2026. This package supplies the previously missing full source packet, four original/v2 candidate examples, native replay, hash preimages and source snapshots. It is review evidence; production v2 reports, scoring and shared version/serialization contracts remain pending. No production files need replacing.

Start with docs/expansion-plan/se-report-review-and-version-proposal.md. Original examples remain report v1. The separate v2 examples are candidates; the candidate report-contract label appears only in file metadata. Communication/Weather records are labeled v1 Imaging mechanics proxies. Their proposed new-objective reports cannot be published against the Imaging source configs.

Extract this ZIP separately. The minimal historical project at reconstruction/project is runnable for these headless checks only; it is not a full game/export. It contains original source/data files from 4c65496, matching the eight hashes in the source packet. The manifest hashes every supplied member except itself. Historical packet/probe files and recorded keys are unchanged.

With Godot 4.7.2, set $godot to your actual executable and $review to the extracted reconstruction/project directory:

```powershell
& $godot --headless --path $review --log-file "$review/evidence-check.log" --script res://docs/expansion-plan/evidence/se-report-evidence-check.gd
& $godot --headless --path $review --log-file "$review/reconstruction.log" --script res://se-binding-reconstruction.gd
```

Expected: 85 evidence checks pass, and native reconstruction ends with zero probe failures. Reconstruction writes se-binding-reconstruction.json in this separate historical project. For each reconstructed case, execution_key equals the original source packet's case key; SHA256 of the UTF-8 execution_key_preimage equals that key; parsing the preimage matches config/final_state/events/validation. The supplied preimage file permits the same byte-level check without rerunning physics.

Known unresolved issue: all eight stored keys differ if input_key is recomputed from directly JSON-loaded dictionaries. Godot full-precision JSON serializes integer [1] differently from the JSON-parsed float [1.0]. The checker prints this caveat. SE/KE2 must agree normalization or retained bytes for transported records; do not silently replace historical keys. The original failing check log is included. No current in-memory storage failure is asserted by this transport test.

The native replay and evidence checks are independent of report-v2 production support. Readiness, source credits and raw captures retain existing meanings. Scoring, HPC sparse-map/contact/weather/sampling semantics, custom identity, final saved-record properties/digest and UI acceptance remain open. Files linked outside this package require the full project checkout. No teammate message or remote action has been performed.
