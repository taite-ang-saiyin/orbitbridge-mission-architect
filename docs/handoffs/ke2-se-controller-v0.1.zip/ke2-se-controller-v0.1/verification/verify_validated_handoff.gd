extends SceneTree
const Evaluator = preload("res://scripts/evaluation/mission_evaluator.gd")
func _initialize() -> void:
    var base: String = "res://data/ke2_bundle/"
    var config: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(base + "original-config.json"))
    var state: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(base + "final-state.json"))
    var events: Array = JSON.parse_string(FileAccess.get_file_as_string(base + "events.json"))
    var before: Array = [config.duplicate(true), state.duplicate(true), events.duplicate(true)]
    var expected: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://docs/handoffs/ke3_validated_1u_55d4f33_9dfd942_20261114_01/evaluation-v0.1.json"))
    expected["report"]["schema_version"] = 1
    expected["report"]["score"] = 25
    var result: Dictionary = Evaluator.evaluate_mission(config, state, events)
    if result != expected or Evaluator.evaluate_hpc_state(state) != result or before != [config, state, events]:
        push_error("Current evaluator differs from the supplied validated report or changed inputs.")
        quit(1)
        return
    print("PASS current evaluator exactly reproduces original validated report through both APIs and preserves inputs.")
    quit(0)
