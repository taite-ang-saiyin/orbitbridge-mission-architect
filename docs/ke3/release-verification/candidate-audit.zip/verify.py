from pathlib import Path
import subprocess,json,re,sys
R=Path(__file__).resolve().parent;W=R/'worktree';E=R/'evidence';phase=sys.argv[1];L=E/phase;L.mkdir(exist_ok=True)
ENGINE=r'C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe';records=[]
def run(name,args,timeout=110):
 cmd=[ENGINE,'--path',str(W),*args]
 try:
  p=subprocess.run(cmd,cwd=W,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout);t=p.stdout+p.stderr;code=p.returncode
 except subprocess.TimeoutExpired as ex:
  t=(ex.stdout or b'').decode('utf-8',errors='replace')+(ex.stderr or b'').decode('utf-8',errors='replace')+'\nWATCHDOG TIMEOUT';code=124
 log=L/(name+'.log');log.write_text(t,encoding='utf-8');errors=[s for s in t.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|Parse Error|Assertion failed|WATCHDOG TIMEOUT',s)]
 records.append({'name':name,'argv':cmd,'exit':code,'errors':errors,'log':str(log)});(L/'commands.json').write_text(json.dumps(records,indent=2));print(name,code,'errors',len(errors),flush=True);print('\n'.join(t.splitlines()[-3:]),flush=True)
 return code==0 and not errors
if not run('import',['--headless','--editor','--import'],130):raise SystemExit(1)
for name in ['test_hpc','ke2_results_integration','integration_smoke','operations_smoke','prototype_smoke']:
 run(name,['--headless','--script','res://tests/'+name+'.gd'])
for mode in ['headless','windowed']:
 run('six-checkpoint-'+mode,(['--headless'] if mode=='headless' else ['--rendering-method','gl_compatibility'])+['--script',str(R/'target_probe.gd'),'--',str(L/mode)])
raise SystemExit(1 if any(c['exit'] or c['errors'] for c in records) else 0)
