extends SceneTree
const Runtime=preload("res://scripts/integration/mission_runtime.gd")
const Results=preload("res://scripts/integration/mission_results.gd")
const Step=preload("res://core/MissionStepEngine.gd")
const Catalog=preload("res://data/mock/DesignCatalog.gd")
var out: String
var checks: Array=[]
var failures: int=0
func _initialize() -> void:
	out=OS.get_cmdline_user_args()[0]
	DirAccess.make_dir_recursive_absolute(out)
	call_deferred("run")
func check(value: bool,text: String) -> void:
	checks.append({"pass":value,"check":text})
	if not value:
		failures+=1
		print("FAIL ",text)
func save(name: String,data: Variant) -> void:
	var f=FileAccess.open(out.path_join(name+".json"),FileAccess.WRITE)
	f.store_string(JSON.stringify(data,"  "))
func settle() -> void:
	for i in 8: await process_frame
func capture(name: String) -> void:
	if DisplayServer.get_name()=="headless":return
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png(out.path_join(name+".png"))
func buttons(node: Node) -> Array:
	var rows: Array=[]
	if node is Button:rows.append(node.text)
	for child in node.get_children():rows.append_array(buttons(child))
	return rows
func run() -> void:
	var app=load("res://scenes/Main.tscn").instantiate()
	root.add_child(app)
	await settle()
	root.mode=Window.MODE_WINDOWED
	root.min_size=Vector2i(640,480)
	root.size=Vector2i(1280,720)
	app.show_screen(1)
	await settle()
	app.current.name_input.text="KE3 exact KE2 SE branch check"
	app.current.name_input.text_changed.emit(app.current.name_input.text)
	app.current.observation_input.value=4
	app.state.required_returned_data_mb=30
	app.state.orbit="Polar – 600 km"
	app.current.next_button.pressed.emit()
	await settle()
	check(app.current.screen_id=="SpacecraftBuilder","Creator→actual Builder")
	app.current.next_button.pressed.emit()
	await settle()
	check(app.current.screen_id=="FlightReadiness" and not app.current.next_button.disabled,"Actual KE1 Readiness enables Launch")
	var validation: Dictionary=app.current.validation.duplicate(true)
	check(validation.ready_to_launch and validation.checks.size()==8 and validation.metrics.total_mass_g==1060 and validation.metrics.total_cost_credits==82,"Readiness actual8checks1060g82credits")
	check(validation.checks.profile_mass.source_id=="cubesat_101_1u_sample" and validation.checks.profile_mass.comparator=="<","Actual selected profile/source binding")
	app.current.next_button.pressed.emit()
	await settle()
	check(app.current.screen_id=="MissionOperations","Launch→HPC policy Operations")
	var trace: Dictionary=app.state.run_trace.duplicate(true)
	check(trace.config==validation.config and trace.validation==validation,"HPC trace keeps validated config/readiness")
	check(trace.config.design=={"instrument_id":"instrument_basic","bus_id":"bus_basic","battery_id":"battery_standard","solar_id":"solar_standard","storage_id":"storage_standard","radio_id":"radio_basic","launch_profile_id":"cubesat_1u_sample","launcher_id":"small","orbit_id":"high_inc"},"Canonical IDs all match expected catalog selections")
	var actual_buttons: Array=buttons(app.current)
	save("operations-controls",{"buttons":actual_buttons,"interaction":"Policy playback; no manual Observe/Transmit/Power-save controls"})
	check(not actual_buttons.has("Observe") and not actual_buttons.has("Transmit"),"Manual controls absent; checks scoped to implemented playback")
	check(app.current.navigate.get_connections().size()==1,"Operations navigate connected once")
	app.current.step_button.pressed.emit()
	check(app.current.event_index==1,"Step selects next provider frame")
	app.current.play_button.pressed.emit()
	app.current._process(1.0)
	check(app.current.playing and app.current.playhead>0,"Play advances playback")
	app.current.pause_button.pressed.emit()
	var stopped: float=app.current.playhead
	app.current._process(1.0)
	check(app.current.playhead==stopped,"Pause preserves playback position")
	for index in trace.frames.size():
		app.current.select_event(index)
		var s: Dictionary=trace.frames[index].state
		check(app.current.DATA.frames[index].state==s and "Captured %s · Returned %.3f MB"%[s.observations_completed,s.returned_data_mb] in app.current.telemetry.text and "Battery %.3f"%s.energy_wh in app.current.telemetry.text,"HUD matches native frame"+str(index))
	check(trace.events==trace.final_state.event_log,"Full provider-ordered history retained")
	var last: int=-1
	for i in trace.events.size():
		var e: Dictionary=trace.events[i]
		check(e.event_id=="evt_%03d"%i and e.step_index>=last and e.run_id==trace.final_state.run_id and e.mission_id==trace.final_state.mission_id,"Ordered run-bound event"+str(i))
		last=e.step_index
	check(trace.final_state.phase=="finished" and trace.final_state.step_index==trace.final_state.total_steps,"Actual terminal duration")
	await capture("candidate-operations-terminal")
	app.current.next_button.pressed.emit()
	await settle()
	var page=app.current
	check(page.screen_id=="DebriefCompare","Actual Results reached")
	var payload: Dictionary=Results.presentation(trace)
	var model: Dictionary=page.report_view.get_debrief_model()
	check(model.presentation_state=="report" and model.status==payload.report.status and model.score==str(payload.report.score),"Debrief status/score from actual KE2")
	check(payload.report.run_id==trace.final_state.run_id and payload.report.observations_completed==trace.final_state.observations_completed and payload.report.returned_data_mb==trace.final_state.returned_data_mb,"Actual report belongs to this run")
	check("Credit scope: readiness" in model.credits and "1060" in model.credits and "1330" in model.credits,"Executed readiness credit visible")
	check(page.report_view.retry_requested.get_connections().size()==1,"Retry connected once")
	var before_history: Array=app.state.run_history.duplicate(true)
	for i in 3:
		app.show_screen(5)
		await settle()
		check(app.current.navigate.get_connections().size()==1 and app.current.report_view.retry_requested.get_connections().size()==1 and app.state.run_history==before_history,"Reentry no duplicate signals/history"+str(i))
	page=app.current
	await capture("candidate-results")
	page.report_view._credits_button.pressed.emit()
	await settle()
	await capture("candidate-credits")
	save("ui-run",{"trace":trace,"payload":payload,"model":model,"execution_key":Results.input_key(trace),"run_id":trace.final_state.run_id,"scope":"Fresh programmatic actual route; not release footage or human playtest"})
	# Same-run native copied rejection, never appended to normal UI trace.
	for frame in trace.frames:
		if frame.state.phase=="operating" and not frame.state.in_ground_contact and frame.state.stored_data_mb>0:
			var s: Dictionary=frame.state.duplicate(true)
			var rejected: Dictionary=Step.request_action(s,"transmit")
			check(rejected.ok and not rejected.allowed and rejected.events[0].code=="NO_LINK_WINDOW","Separate engine probe returns blocked event/reason")
			for field in ["step_index","energy_wh","stored_data_mb","returned_data_mb","observations_completed"]:check(s[field]==rejected.state[field],"Rejected probe unchanged "+field)
			save("separate-rejection-probe",{"before":s,"reply":rejected,"scope":"Outside actual UI run history"})
			break
	check(app.state.run_trace.events==trace.events,"Separate probe did not alter UI history")
	# Actual native evidence run for reason/evidence presentation (separate API run).
	var component: Dictionary=Step.init_run(trace.config,trace.final_state.scenario_snapshot,"six_check_evidence","six_check_mission").state
	var attempted: bool=false
	while component.phase=="operating":
		var action: String="power_save"
		if component.step_index==1:action="observe"
		elif component.step_index==7:action="transmit"
		elif component.step_index==8 and not attempted:
			action="transmit"
			attempted=true
		component=Step.request_action(component,action).state
	var evidence_trace: Dictionary={"config":trace.config.duplicate(true),"final_state":component,"events":component.event_log.duplicate(true),"validation":validation.duplicate(true)}
	var evidence: Dictionary=Results.presentation(evidence_trace)
	page.report_view.set_inputs(evidence.context,evidence.state,evidence.report)
	var evidence_model: Dictionary=page.report_view.get_debrief_model()
	check("evt_008" in evidence_model.causes and "Step 8" in evidence_model.causes and "NO_LINK_WINDOW" in evidence_model.causes,"Actual report cause resolves same-run event")
	check("Credit scope: feedback_vocabulary" in evidence_model.credits,"Actual cause receives supplied vocabulary scope")
	save("component-evidence",{"trace":evidence_trace,"payload":evidence,"model":evidence_model,"scope":"API-only separate component, not normal UI history"})
	var mismatch: Dictionary=evidence.report.duplicate(true)
	mismatch.mission_id="not-this-mission"
	page.report_view.set_inputs(evidence.context,evidence.state,mismatch)
	var rejected_model: Dictionary=page.report_view.get_debrief_model()
	check(rejected_model.presentation_state!="report","Wrong-mission same-run-ID report is rejected")
	check(not "Credit scope: feedback_vocabulary" in rejected_model.credits,"Rejected report does not leak feedback credit")
	check("Credit scope: readiness" in rejected_model.credits or "Profile credit:" in rejected_model.credits,"Executed readiness attribution survives invalid report")
	save("wrong-mission-display",rejected_model)
	# Missing linked event preserves valid report, as supplied.
	var missing: Dictionary=evidence.report.duplicate(true)
	missing.root_causes[0].evidence_event_ids=["missing-test-id"]
	page.report_view.set_inputs(evidence.context,evidence.state,missing)
	check(page.report_view.get_debrief_model().presentation_state=="report" and "Evidence Unavailable" in page.report_view.get_debrief_model().causes,"Missing event keeps valid report readable")
	var survey: Dictionary=Catalog.DEFAULTS.duplicate(true)
	Catalog.ensure(survey)
	survey.objective="Survey Target Regions"
	var launched: Dictionary=Runtime.launch(survey)
	check(launched.ok,"Survey validation/HPC route can execute")
	var result: Dictionary=Results.evaluate_trace(survey.run_trace)
	check(not result.ok and result.error.field_path=="config.mission.objective","Actual evaluator explicitly rejects unsupported Survey")
	save("survey",{"trace":survey.run_trace,"evaluation":result})
	var original: Dictionary=app.state.run_trace.duplicate(true)
	app.show_screen(5)
	await settle()
	app.current.report_view._retry_button.pressed.emit()
	await settle()
	check(app.current.screen_id=="MissionOperations" and app.state.run_trace.final_state.run_id!=original.final_state.run_id,"Implemented Retry creates own new run and Operations")
	check(app.state.run_trace.config.mission==original.config.mission and app.current.event_index==0,"Retry retains mission and resets playback")
	check(app.state.run_trace.frames[0].state.observations_completed==0 and app.state.run_trace.frames[0].state.event_log.is_empty(),"Retry initial native counters/history fresh")
	save("retry",{"trace":app.state.run_trace,"behavior":"Immediate same-design relaunch; not newer KE3 editable Retry","origin":original.final_state.run_id})
	save("checks",{"passed":checks.size()-failures,"failed":failures,"checks":checks,"run_id":trace.final_state.run_id,"execution_key":Results.input_key(trace),"manual_controls":"NOT AVAILABLE: policy playback","browser":"NOT TESTED","human":"NOT TESTED"})
	print("EXACT BRANCH CHECK: ",checks.size()-failures," passed; ",failures," failed; ",trace.final_state.run_id)
	app.queue_free()
	await process_frame
	quit(1 if failures else 0)
