# Exact commands and exits

Test entries below show exact Windows process command lines/argv; when pasting a quoted executable path into PowerShell, prefix it with `&`.

Recorded 2026-11-14T19:00:02+06:30. Commands executed locally; no push, merge, publication, submission or messaging.

## Requested branch fetch

Working directory: C:\Workspace\OrbitBridge\orbitbridge-mission-architect

```powershell
git -c http.sslBackend=openssl -c http.version=HTTP/1.1 -c http.lowSpeedLimit=1000 -c http.lowSpeedTime=15 fetch origin refs/heads/integration/ke2-se-results-d60d224:refs/remotes/origin/integration/ke2-se-results-d60d224
```
Exit: 0. Resolved SHA: 14c0f973c140e9644650e94e769b6b1b3dfb3951. Fetch result was observed in the tool response; subsequent revision records are saved below.

## 1. clean: --import

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --editor --import
```
Exit: 0.
Log: [import.log](evidence/clean/import.log)

## 2. clean: test_hpc.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script res://tests/test_hpc.gd
```
Exit: 0.
Log: [test_hpc.log](evidence/clean/test_hpc.log)

## 3. clean: ke2_results_integration.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script res://tests/ke2_results_integration.gd
```
Exit: 0.
Log: [ke2_results_integration.log](evidence/clean/ke2_results_integration.log)

## 4. clean: integration_smoke.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script res://tests/integration_smoke.gd
```
Exit: 0.
Log: [integration_smoke.log](evidence/clean/integration_smoke.log)

## 5. clean: operations_smoke.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script res://tests/operations_smoke.gd
```
Exit: 0.
Log: [operations_smoke.log](evidence/clean/operations_smoke.log)

## 6. clean: prototype_smoke.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script res://tests/prototype_smoke.gd
```
Exit: 0.
Log: [prototype_smoke.log](evidence/clean/prototype_smoke.log)

## 7. clean: headless

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script C:\Workspace\OrbitBridge\Event\ke3_release_verification\target_probe.gd -- C:\Workspace\OrbitBridge\Event\ke3_release_verification\evidence\clean\headless
```
Exit: 1.
Log: [six-checkpoint-headless.log](evidence/clean/six-checkpoint-headless.log)

## 8. clean: windowed

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --rendering-method gl_compatibility --script C:\Workspace\OrbitBridge\Event\ke3_release_verification\target_probe.gd -- C:\Workspace\OrbitBridge\Event\ke3_release_verification\evidence\clean\windowed
```
Exit: 1.
Log: [six-checkpoint-windowed.log](evidence/clean/six-checkpoint-windowed.log)

## 9. patched: --import

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --editor --import
```
Exit: 0.
Log: [import.log](evidence/patched/import.log)

## 10. patched: test_hpc.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script res://tests/test_hpc.gd
```
Exit: 0.
Log: [test_hpc.log](evidence/patched/test_hpc.log)

## 11. patched: ke2_results_integration.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script res://tests/ke2_results_integration.gd
```
Exit: 0.
Log: [ke2_results_integration.log](evidence/patched/ke2_results_integration.log)

## 12. patched: integration_smoke.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script res://tests/integration_smoke.gd
```
Exit: 0.
Log: [integration_smoke.log](evidence/patched/integration_smoke.log)

## 13. patched: operations_smoke.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script res://tests/operations_smoke.gd
```
Exit: 0.
Log: [operations_smoke.log](evidence/patched/operations_smoke.log)

## 14. patched: prototype_smoke.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script res://tests/prototype_smoke.gd
```
Exit: 0.
Log: [prototype_smoke.log](evidence/patched/prototype_smoke.log)

## 15. patched: headless

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --headless --script C:\Workspace\OrbitBridge\Event\ke3_release_verification\target_probe.gd -- C:\Workspace\OrbitBridge\Event\ke3_release_verification\evidence\patched\headless
```
Exit: 0.
Log: [six-checkpoint-headless.log](evidence/patched/six-checkpoint-headless.log)

## 16. patched: windowed

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --rendering-method gl_compatibility --script C:\Workspace\OrbitBridge\Event\ke3_release_verification\target_probe.gd -- C:\Workspace\OrbitBridge\Event\ke3_release_verification\evidence\patched\windowed
```
Exit: 0.
Log: [six-checkpoint-windowed.log](evidence/patched/six-checkpoint-windowed.log)

## 17. preparation: --show-current

Working directory: C:\Workspace\OrbitBridge\orbitbridge-mission-architect

```powershell
git branch --show-current
```
Exit: 0.

## 18. preparation: HEAD

Working directory: C:\Workspace\OrbitBridge\orbitbridge-mission-architect

```powershell
git rev-parse HEAD
```
Exit: 0.

## 19. preparation: --porcelain=v1

Working directory: C:\Workspace\OrbitBridge\orbitbridge-mission-architect

```powershell
git status --porcelain=v1
```
Exit: 0.

## 20. preparation: ke2-se-results-d60d224

Working directory: C:\Workspace\OrbitBridge\orbitbridge-mission-architect

```powershell
git rev-parse origin/integration/ke2-se-results-d60d224
```
Exit: 0.

## 21. preparation: ls-files

Working directory: C:\Workspace\OrbitBridge\orbitbridge-mission-architect

```powershell
git ls-files
```
Exit: 0.

## 22. preparation: source

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification

```powershell
git clone --no-checkout --no-hardlinks C:\Workspace\OrbitBridge\orbitbridge-mission-architect C:\Workspace\OrbitBridge\Event\ke3_release_verification\source
```
Exit: 0.

## 23. preparation: 14c0f973c140e9644650e94e769b6b1b3dfb3951

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\source

```powershell
git worktree add --detach C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree 14c0f973c140e9644650e94e769b6b1b3dfb3951
```
Exit: 0.

## 24. final verification: --show-current

Working directory: C:\Workspace\OrbitBridge\orbitbridge-mission-architect

```powershell
git branch --show-current
```
Exit: 0.

## 25. final verification: HEAD

Working directory: C:\Workspace\OrbitBridge\orbitbridge-mission-architect

```powershell
git rev-parse HEAD
```
Exit: 0.

## 26. final verification: --porcelain=v1

Working directory: C:\Workspace\OrbitBridge\orbitbridge-mission-architect

```powershell
git status --porcelain=v1
```
Exit: 0.

## 27. final verification: HEAD

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
git rev-parse HEAD
```
Exit: 0.

## 28. final verification: main

Working directory: C:\Workspace\OrbitBridge\orbitbridge-mission-architect

```powershell
git rev-parse origin/main
```
Exit: 0.

## 29. final verification: 14c0f973c140e9644650e94e769b6b1b3dfb3951

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
git diff --stat e71aaf8712b9b9438247cb514467bb33bc015989 14c0f973c140e9644650e94e769b6b1b3dfb3951
```
Exit: 0.

## 30. final verification: --format=%H %s

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
git log -6 "--format=%H %s"
```
Exit: 0.

## 31. final verification: 14c0f973c140e9644650e94e769b6b1b3dfb3951

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
git merge-base --is-ancestor b23de72 14c0f973c140e9644650e94e769b6b1b3dfb3951
```
Exit: 0.

## 32. final verification: debrief_screen.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
git diff -- ke3/debrief_screen.gd
```
Exit: 0.

## 33. final verification: --check

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
git diff --check
```
Exit: 0.

## 34. final verification: --short

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
git status --short
```
Exit: 0.

## 35. final verification: --version

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --version
```
Exit: 0.

## 36. final verification: debrief_screen.gd

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --headless --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --check-only --script res://ke3/debrief_screen.gd
```
Exit: 0.

## 37. visible supplement: visible

Working directory: C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree

```powershell
C:\Workspace\OrbitBridge\Godot_v4.7.2-stable_win64\Godot_v4.7.2-stable_win64_console.exe --path C:\Workspace\OrbitBridge\Event\ke3_release_verification\worktree --rendering-method gl_compatibility --script C:\Workspace\OrbitBridge\Event\ke3_release_verification\visible_probe.gd -- C:\Workspace\OrbitBridge\Event\ke3_release_verification\evidence\visible
```
Exit: 0.
Log: [visible.log](evidence/visible.log)
